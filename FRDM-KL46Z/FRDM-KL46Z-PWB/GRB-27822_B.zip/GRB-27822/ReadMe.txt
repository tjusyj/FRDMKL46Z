README for GRB-27822_B.zip

Company Part Number: 170-27822 REV B

Date : Mon, 01 Apr 2013 13:19:58 GMT

Freescale Semiconductor
7700 West Parmer Lane
Austin, TX 78729
Maildrop: PL59

Company Contact: [full_name]
	Work Phone: (512)996-XXXX
		 Email:	 [email]@freescale.com